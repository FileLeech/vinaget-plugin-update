<?php

$this->acc = array(
# Example: 'accounts'	=> array('user:pass','cookie'),
# Example with letitbit.net: 'accounts'    => array('user:pass','cookie','prekey=xxxx'),


	'rapidshare.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'hotfile.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'filefactory.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'depositfiles.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'netload.in'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'easy-share.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'uploading.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'uploaded.to'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'megashares.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'bitshare.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'gigasize.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'mediafire.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'oron.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'uploadstation.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'enterupload.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'4shared.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'filepost.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'filesmonster.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'letitbit.net'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'crocko.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'freakshare.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'extabit.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'turbobit.net'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'share-online.biz'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'sendspace.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'rapidgator.net'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'depfile.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'jumbofiles.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'bayfiles.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'cloudnator.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

	'ryushare.com'		=> array(
								'max_size'	=> 2048,
								'accounts'	=> array(),
							),

);
$this->max_size_other_host = 2048;

?>